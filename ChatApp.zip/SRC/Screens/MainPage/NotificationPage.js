import { StatusBar, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import Bottomnavbar from '../../Components/Bottomnavbar'
import { formHead } from '../../CommonCss/formcss'
import { container } from '../../CommonCss/paagecss'
import TopNavBar from '../../Components/TopNavBar'


const NotificationPage = ({navigation}) => {
  return (
    <View style={styles.container} >
      <StatusBar/>
      <TopNavBar navigation={navigation}/>
      <Bottomnavbar navigation={navigation} page="NotificationPage"/>
      <Text style={formHead}>Notification</Text>
      
    </View>
  )
}

export default NotificationPage

const styles = StyleSheet.create({
  container:{
    width:"100%",
    height:"100%",
    backgroundColor:"white",
    paddingVertical:50
  }
})